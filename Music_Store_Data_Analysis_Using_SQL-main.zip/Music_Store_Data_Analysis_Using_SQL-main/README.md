# Music_Store_Data_Analysis_Using_SQL
This SQL project presents an analysis of a music store's playlist database, providing insights into the store's business expansion. The study of this data will enhance our understanding of the store's growth trajectory in the music industry.

# DataBase and Tools
 -> PostgreSQL
 -> PgAdmin4
 
